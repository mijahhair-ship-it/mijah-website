"use server";

// This file is temporarily empty. 
// The contact form has been converted to a client-side component.
// We can re-introduce server actions here later if needed.
