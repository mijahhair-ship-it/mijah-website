import { PlaceHolderImages } from "@/lib/placeholder-images";
import Image from "next/image";

export default function AboutPage() {
    const artisanImage = PlaceHolderImages.find(p => p.id === 'artisan-portrait');

    return (
        <main id="page-about" className="page pt-24 md:pt-32 pb-12 md:pb-20 overflow-hidden">
            <div className="max-w-5xl mx-auto px-6">
                
                <div className="mb-12 md:mb-24 text-center gs-reveal-page">
                    <span className="text-accent text-xs uppercase tracking-[0.3em] font-bold block mb-4">À propos d'Ylamante Elec</span>
                    <h1 className="font-display text-4xl md:text-7xl mb-6 md:mb-8 leading-tight">L'Artisanat,<br/>élevé au rang d'art.</h1>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16 mb-16 md:mb-24 items-start gs-reveal-page">
                    <div className="aspect-[4/5] bg-gray-200 rounded-sm overflow-hidden relative shadow-xl">
                       {artisanImage && (
                         <Image 
                            src={artisanImage.imageUrl} 
                            alt="Artisan Ylamante" 
                            fill
                            className="object-cover w-full h-full"
                            data-ai-hint={artisanImage.imageHint}
                        />
                       )}
                    </div>
                    <div className="space-y-6 md:space-y-8">
                        <div>
                            <h2 className="font-display text-2xl md:text-3xl mb-4 md:mb-6">L'Excellence Technique au Service de l'Émotion : L'Histoire d'Ylamante Elec</h2>
                            <p className="text-foreground/70 leading-relaxed text-sm md:text-base">
                                Ylamante Elec est né d'une ambition profonde : transcender la simple exécution technique pour redonner ses lettres de noblesse aux métiers de l'électricité et de la rénovation intérieure. Pour nous, un chantier n'est pas qu'une suite de tâches à accomplir, c'est une promesse de sécurité et de confort faite à nos clients.
                            </p>
                            <p className="text-foreground/70 leading-relaxed mt-4 text-sm md:text-base">
                                Ancrés au cœur de Bornel (60540), nous rayonnons dans toute la région avec une philosophie qui guide chacun de nos gestes : l'harmonie par la précision technique. Nous croyons fermement qu'une installation électrique parfaitement réalisée est le fondement invisible mais essentiel de la sérénité au quotidien.
                            </p>
                        </div>
                        
                        <div>
                            <h3 className="font-display text-xl md:text-2xl mb-4">Notre Vision de l'Habitat</h3>
                            <p className="text-foreground/70 leading-relaxed text-sm md:text-base">
                                Qu'il s'agisse de la mise aux normes rigoureuse d'un tableau électrique obsolète ou de la réhabilitation complète d'un logement, nous abordons chaque projet avec une exigence artisanale et un souci du détail quasi obsessionnel. Là où d'autres se contentent de « brancher » ou de « poser », nous concevons des systèmes durables et intelligents.
                            </p>
                        </div>

                        <div>
                            <h3 className="font-display text-xl md:text-2xl mb-4">Bien plus qu'une Intervention</h3>
                            <p className="text-foreground/70 leading-relaxed mb-4 text-sm md:text-base">
                                Chez Ylamante Elec, notre rôle dépasse largement le dépannage ou l'installation :
                            </p>
                            <ul className="space-y-4 text-foreground/70 leading-relaxed text-sm md:text-base">
                                <li className="flex gap-3"><span className="text-accent font-bold">•</span> <span><span className="font-semibold text-foreground/80">Sécuriser :</span> Nous protégeons ce que vous avez de plus cher en garantissant une conformité totale aux normes les plus strictes.</span></li>
                                <li className="flex gap-3"><span className="text-accent font-bold">•</span> <span><span className="font-semibold text-foreground/80">Embellir :</span> Par le biais de la conception lumière et de solutions LED sur-mesure, nous révélons le potentiel architectural de vos espaces.</span></li>
                                <li className="flex gap-3"><span className="text-accent font-bold">•</span> <span><span className="font-semibold text-foreground/80">Pérenniser :</span> En alliant réparation technique et harmonie spatiale, nous valorisons votre patrimoine immobilier sur le long terme.</span></li>
                            </ul>
                        </div>
                        
                        <p className="text-foreground/70 leading-relaxed italic border-l-2 border-accent pl-4 text-sm md:text-base">
                            Choisir Ylamante Elec, c'est confier ses projets à un partenaire qui voit dans chaque câble et chaque finition l'opportunité de créer un environnement d'exception.
                        </p>
                    </div>
                </div>

                <div className="bg-white p-8 md:p-16 border border-foreground/5 text-center gs-reveal-page shadow-sm">
                    <h3 className="font-display text-xl md:text-2xl mb-6 md:mb-8 text-accent">L’excellence qui se devine sans jamais s’imposer.</h3>
                    <p className="text-lg md:text-2xl font-light leading-snug max-w-3xl mx-auto">
                        Chaque détail est maîtrisé, chaque intervention parfaitement sécurisée, chaque finition pensée pour sublimer l’existant. Notre artisanat multiservices incarne le luxe discret : efficace, sûr et irréprochable.
                    </p>
                </div>

            </div>
        </main>
    );
}
