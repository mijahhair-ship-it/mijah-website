import { PlaceHolderImages } from "@/lib/placeholder-images";
import Image from "next/image";
import { Play } from 'lucide-react';

const portfolioItems = [
    {
        id: 'portfolio-1',
        title: 'Tableau Électrique',
        category: 'Mise aux normes',
        className: 'aspect-square',
    },
    {
        id: 'portfolio-2',
        title: 'Réhabilitation Salon',
        category: 'Électricité Générale',
        className: 'aspect-[3/4] md:col-span-2',
    },
    {
        id: 'portfolio-3',
        title: 'Vidéo : Remplacement Tableau',
        category: 'Mise aux normes',
        className: 'aspect-video md:col-span-2',
        isVideo: true,
    },
    {
        id: 'portfolio-4',
        title: 'Détail Finition',
        category: 'Dépannage',
        className: 'aspect-square',
    },
    {
        id: 'portfolio-5',
        title: 'Effet Avant/Après',
        category: 'Éclairage',
        className: 'md:col-span-3 aspect-video',
        isVideo: true,
    },
];

const MediaCard = ({ item }: { item: (typeof portfolioItems)[0] }) => {
    const imageData = PlaceHolderImages.find(p => p.id === item.id);

    if (!imageData) return null;

    const isEmbeddableVideo = item.isVideo && imageData.imageUrl.endsWith('.mp4');

    return (
        <div className={`media-card group gs-reveal-page interactive-media rounded-sm shadow-md overflow-hidden ${item.className} ${item.isVideo ? 'cursor-video' : ''}`}>
            {isEmbeddableVideo ? (
                <video 
                    src={imageData.imageUrl}
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="object-cover w-full h-full"
                />
            ) : (
                <Image 
                    src={imageData.imageUrl}
                    alt={item.title}
                    fill
                    className="object-cover"
                    data-ai-hint={imageData.imageHint}
                />
            )}
            
            <div className="absolute inset-0 bg-black/40 md:bg-black/20 group-hover:bg-black/40 transition-colors"></div>
            
            {item.isVideo && !isEmbeddableVideo && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 md:w-16 md:h-16 rounded-full border border-white flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                    <Play fill="currentColor" className="ml-1" />
                </div>
            )}
            
            <div className="absolute bottom-4 left-4 md:bottom-6 md:left-6 text-white opacity-100 md:opacity-0 group-hover:opacity-100 transition-all duration-500 translate-y-0 md:translate-y-4 group-hover:translate-y-0">
                <h3 className="font-display text-lg md:text-xl">{item.title}</h3>
                <p className="text-[10px] tracking-[0.2em] uppercase text-accent font-semibold">{item.category}</p>
            </div>
        </div>
    );
};


export default function PortfolioPage() {

    return (
        <main id="page-portfolio" className="page pt-24 md:pt-32 pb-12 md:pb-20 overflow-hidden">
            <div className="max-w-7xl mx-auto px-6">
                
                <div className="mb-12 md:mb-20 text-center gs-reveal-page">
                    <span className="text-accent text-xs uppercase tracking-[0.3em] font-bold block mb-4">Portfolio</span>
                    <h1 className="font-display text-3xl md:text-7xl mb-6 leading-tight">Nos Réalisations</h1>
                    <p className="text-foreground/60 max-w-2xl mx-auto text-sm md:text-base">Une sélection de nos interventions en électricité, éclairage et réhabilitation. (Photos et vidéos d'illustration).</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
                    {portfolioItems.map(item => <MediaCard key={item.id} item={item} />)}
                </div>
            </div>
        </main>
    );
}
