import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from '@/components/ui/toaster';
import { InteractiveProvider } from '@/components/interactive-provider';
import Script from 'next/script';

export const metadata: Metadata = {
  title: 'Ylamante Elec | Artisan Multiservices & Électricité',
  description: 'Artisan multiservices. Remplacement de tableaux électriques, mise aux normes et réhabilitation complète de votre intérieur. Apportez la sérénité à votre habitat.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" className="scroll-smooth" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500&family=Space+Grotesk:wght@300;400;500&display=swap" rel="stylesheet" />
      </head>
      <body className="font-sans font-light" suppressHydrationWarning>
        <InteractiveProvider>
          {children}
        </InteractiveProvider>
        <Toaster />
        <Script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" strategy="beforeInteractive" />
        <Script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js" strategy="beforeInteractive" />
      </body>
    </html>
  );
}
