"use client";

import { generateProjectDescription, type GenerateProjectDescriptionInput } from "@/ai/flows/generate-project-description";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState, useTransition } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";

const formSchema = z.object({
  scope: z.string().min(10, {
    message: "Veuillez fournir une portée de projet d'au moins 10 caractères.",
  }),
  outcome: z.string().min(10, {
    message: "Veuillez fournir un résultat souhaité d'au moins 10 caractères.",
  }),
});

export function GenerateDescriptionForm() {
    const [isPending, startTransition] = useTransition();
    const [result, setResult] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            scope: "",
            outcome: "",
        },
    });

    function onSubmit(values: z.infer<typeof formSchema>) {
        setResult(null);
        setError(null);
        startTransition(async () => {
            try {
                const output = await generateProjectDescription(values as GenerateProjectDescriptionInput);
                setResult(output.detailedDescription);
            } catch (e) {
                setError("Une erreur s'est produite lors de la génération de la description.");
                console.error(e);
            }
        });
    }

    return (
        <>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                    <FormField
                        control={form.control}
                        name="scope"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Portée du projet</FormLabel>
                                <FormControl>
                                    <Textarea
                                        placeholder="Ex: Remplacement de tableau électrique, conception d'éclairage, rénovation de maison..."
                                        {...field}
                                    />
                                </FormControl>
                                <FormDescription>
                                    Décrivez brièvement la portée du projet.
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="outcome"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Résultat souhaité</FormLabel>
                                <FormControl>
                                    <Textarea
                                        placeholder="Ex: Sécurité renforcée, esthétique moderne, efficacité énergétique améliorée..."
                                        {...field}
                                    />
                                </FormControl>
                                <FormDescription>
                                    Quel est le résultat souhaité pour le client ?
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <Button type="submit" disabled={isPending}>
                        {isPending ? "Génération en cours..." : "Générer la description"}
                    </Button>
                </form>
            </Form>

            {error && (
                <div className="mt-6 p-4 bg-destructive/10 text-destructive border border-destructive/20 rounded-md">
                    <p>{error}</p>
                </div>
            )}

            {result && (
                <div className="mt-8">
                    <h3 className="text-lg font-semibold font-headline mb-4">Description générée :</h3>
                    <div className="p-4 bg-muted/50 border rounded-md whitespace-pre-wrap text-sm">
                        {result}
                    </div>
                </div>
            )}
        </>
    );
}
