import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { GenerateDescriptionForm } from "./form";

export default function GenerateDescriptionPage() {
    return (
        <main className="container mx-auto py-10 px-4">
            <Card className="max-w-2xl mx-auto">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">Générateur de Description de Projet</CardTitle>
                    <CardDescription>
                        Utilisez cet outil pour créer des descriptions de projet professionnelles et détaillées pour les clients.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <GenerateDescriptionForm />
                </CardContent>
            </Card>
        </main>
    )
}