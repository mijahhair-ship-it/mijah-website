import { PlaceHolderImages } from '@/lib/placeholder-images';
import { ArrowRight, Zap, ShieldCheck, Lightbulb, Home as HomeIcon, Wrench, Plug } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { ContactForm } from '@/components/contact-form';

const services = [
  {
    icon: <Zap className="w-6 h-6 md:w-8 md:h-8" />,
    title: 'Électricité Générale',
    description: "Conception et réalisation d'installations complètes pour le neuf et la rénovation, alliant performance technique et sécurité.",
  },
  {
    icon: <ShieldCheck className="w-6 h-6 md:w-8 md:h-8" />,
    title: 'Mise aux Normes & Tableau',
    description: "Diagnostic approfondi et remplacement de vos tableaux électriques pour une conformité totale aux normes NF C 15-100.",
  },
  {
    icon: <Lightbulb className="w-6 h-6 md:w-8 md:h-8" />,
    title: 'LED & Design Lumineux',
    description: "Création d'ambiances sur-mesure via des solutions LED basse consommation et un éclairage architectural de précision.",
  },
   {
    icon: <HomeIcon className="w-6 h-6 md:w-8 md:h-8" />,
    title: 'Réhabilitation de Logements',
    description: "Une approche multiservices dédiée à la rénovation globale, transformant l'existant en espaces de vie modernes et fonctionnels.",
  },
  {
    icon: <Wrench className="w-6 h-6 md:w-8 md:h-8" />,
    title: 'Dépannage & Maintenance',
    description: "Intervention rapide et précise pour identifier et résoudre vos pannes, assurant la continuité de vos services électriques.",
  },
  {
    icon: <Plug className="w-6 h-6 md:w-8 md:h-8" />,
    title: 'Installations Spécifiques',
    description: "Pose d'équipements spécialisés (domotique, bornes de recharge, chauffage) avec une finition artisanale irréprochable.",
  }
];

const testimonials = [
    {
        quote: "L'intervention fut silencieuse, précise, et a complètement transformé la sécurité de notre maison ancienne.",
        author: "Aurelie M."
    },
    {
        quote: "Au-delà de l'électricité classique. Ils ont apporté un sens du calme et une conscience esthétique à une rénovation complexe.",
        author: "Julien D."
    }
];

export default function HomePage() {
  return (
    <main id="page-home" className="page">
      <header className="relative h-[100svh] flex items-center justify-center overflow-hidden px-6">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute z-0 w-full h-full object-cover"
          src="https://res.cloudinary.com/dvbuuv5qp/video/upload/v1771876546/com_vsugay.mp4"
        />
        <div className="absolute inset-0 bg-primary/60 z-10"></div>
        <div className="relative z-20 max-w-5xl mx-auto flex flex-col items-center text-center text-primary-foreground">
          <h1 className="font-display font-light text-3xl sm:text-5xl md:text-7xl lg:text-8xl leading-[1.1] tracking-tight mb-8">
            Apportez la <span className="text-gradient font-normal">Sérénité</span><br />à votre habitat.
          </h1>
          
          <p className="font-sans text-sm md:text-xl text-primary-foreground/80 max-w-2xl mb-12 px-4">
            Artisan multiservices. Remplacement de tableaux électriques, mise aux normes et réhabilitation complète de votre intérieur.
          </p>
          
          <Link href="/#booking" scroll={true} className="magnetic inline-flex items-center gap-4 border-b border-primary-foreground pb-2 hover:text-accent hover:border-accent transition-colors duration-300">
            <span className="uppercase tracking-widest text-xs md:text-sm">Demander une consultation</span>
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </header>

      <section className="py-20 md:py-32 px-6 bg-secondary overflow-hidden">
        <div className="max-w-7xl mx-auto">
            <div className="mb-12 md:mb-20 gs-reveal">
                <div className="aspect-video w-full overflow-hidden rounded-sm relative media-card shadow-2xl">
                    <video
                        src="https://res.cloudinary.com/dvbuuv5qp/video/upload/v1771876817/0223_1_jnpjbn.mp4"
                        autoPlay
                        loop
                        muted
                        playsInline
                        className="object-cover w-full h-full"
                    />
                </div>
            </div>

            <h2 className="font-display text-center text-2xl md:text-4xl mb-12 md:mb-20 gs-reveal">Nos Domaines d'Expertise</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
              {services.map((service, index) => (
                <div key={index} className="p-8 md:p-10 bg-white border border-foreground/5 hover:border-accent/30 transition-colors duration-500 magnetic group gs-reveal shadow-sm hover:shadow-md">
                    <div className="text-accent mb-6 md:mb-8">{service.icon}</div>
                    <h3 className="font-display text-lg md:text-xl mb-3 md:mb-4">{service.title}</h3>
                    <p className="text-foreground/60 text-xs md:text-sm leading-relaxed">{service.description}</p>
                </div>
              ))}
            </div>

            <div className="text-center mt-12 md:mt-16 gs-reveal">
                <Link href="/about" className="magnetic inline-flex items-center gap-4 text-xs md:text-sm uppercase tracking-widest text-foreground/60 hover:text-accent transition-colors">
                    <span>Découvrir notre philosophie</span>
                    <ArrowRight className="h-4 w-4" />
                </Link>
            </div>
        </div>
      </section>

      <section className="py-20 md:py-32 overflow-hidden bg-primary text-primary-foreground cursor-grab active:cursor-grabbing">
        <div className="max-w-7xl mx-auto px-6 mb-12 md:mb-16">
            <h2 className="font-display text-xs md:text-sm uppercase tracking-[0.3em] text-accent">Voix de la Sérénité</h2>
        </div>
        
        <div className="scroll-snap-container px-6 pb-8 max-w-7xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="scroll-snap-item bg-[#292524] p-8 md:p-16">
              <p className="font-display text-xl md:text-3xl leading-snug mb-6 md:mb-8">"{testimonial.quote}"</p>
              <div className="text-xs md:text-sm tracking-widest uppercase text-accent">— {testimonial.author}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="booking" className="py-20 md:py-32 px-6 bg-white relative">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
              <div className="gs-reveal">
                  <h2 className="font-display text-2xl md:text-4xl mb-8 md:mb-12">Demander une consultation</h2>
                  <ContactForm />
              </div>
              <div className="flex flex-col h-full gs-reveal">
                  <div className="mb-10 md:mb-12 space-y-4">
                      <p className="font-display text-lg">Ylamante Elec</p>
                      <p className="text-foreground/60 text-sm md:text-base">60540 Bornel<br/>France</p>
                      <p className="pt-4"><a href="mailto:ylamante-elec10@gmail.com" className="magnetic hover:text-accent transition-colors text-sm md:text-base">ylamante-elec10@gmail.com</a></p>
                      <p><a href="tel:0660399642" className="magnetic hover:text-accent transition-colors text-sm md:text-base">06 60 39 96 42</a></p>
                  </div>
                  <div className="relative flex-grow min-h-[300px] map-container bg-muted group rounded-sm overflow-hidden shadow-inner">
                      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d41618.33083321569!2d2.1932617655075635!3d49.19125301389809!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e651e18507c721%3A0x40b82c3688b4090!2s60540%20Bornel%2C%20France!5e0!3m2!1sen!2sus!4v1700000000000!5m2!1sen!2sus" className="absolute inset-0 w-full h-full border-0 grayscale opacity-80" allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
                  </div>
              </div>
          </div>
      </section>
    </main>
  );
}
