'use server';
/**
 * @fileOverview A Genkit flow for generating professional and detailed project descriptions.
 *
 * - generateProjectDescription - A function that handles the project description generation process.
 * - GenerateProjectDescriptionInput - The input type for the generateProjectDescription function.
 * - GenerateProjectDescriptionOutput - The return type for the generateProjectDescription function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GenerateProjectDescriptionInputSchema = z.object({
  scope: z.string().describe('A brief description of the project\'s scope, e.g., electrical panel replacement, lighting design, home renovation.'),
  outcome: z.string().describe('The desired outcome for the client, e.g., enhanced safety, modern aesthetics, improved energy efficiency.'),
});
export type GenerateProjectDescriptionInput = z.infer<typeof GenerateProjectDescriptionInputSchema>;

const GenerateProjectDescriptionOutputSchema = z.object({
  detailedDescription: z.string().describe('A professional and detailed project description suitable for client proposals or internal documentation.'),
});
export type GenerateProjectDescriptionOutput = z.infer<typeof GenerateProjectDescriptionOutputSchema>;

export async function generateProjectDescription(input: GenerateProjectDescriptionInput): Promise<GenerateProjectDescriptionOutput> {
  return generateProjectDescriptionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateProjectDescriptionPrompt',
  input: { schema: GenerateProjectDescriptionInputSchema },
  output: { schema: GenerateProjectDescriptionOutputSchema },
  prompt: `You are a highly skilled copywriter specializing in crafting professional and compelling project descriptions for an artisan multiservice company named 'Ylamante Elec'.

Ylamante Elec focuses on bringing serenity to the home through meticulous electrical work, innovative lighting design, and complete home rehabilitation. They value precision, safety, and aesthetic harmony.

Your task is to take brief inputs about a new client job's scope and desired outcome and expand them into a detailed, professional, and persuasive project description. This description should be suitable for client proposals or internal project documentation.

Ensure the language reflects Ylamante Elec's brand values: craftsmanship, reliability, serenity, precision, and aesthetic sensibility.

Input Scope: {{{scope}}}
Input Outcome: {{{outcome}}}

Craft a detailed project description based on the above inputs.`,
});

const generateProjectDescriptionFlow = ai.defineFlow(
  {
    name: 'generateProjectDescriptionFlow',
    inputSchema: GenerateProjectDescriptionInputSchema,
    outputSchema: GenerateProjectDescriptionOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
