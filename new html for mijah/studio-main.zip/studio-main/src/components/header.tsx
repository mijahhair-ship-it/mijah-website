import Link from "next/link";
import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { cn } from "@/lib/utils";

type HeaderProps = {
  menuOpen: boolean;
  toggleMenu: () => void;
  isPreloading: boolean;
};

export function Header({ menuOpen, toggleMenu, isPreloading }: HeaderProps) {
  const logo = PlaceHolderImages.find((p) => p.id === 'logo');

  return (
    <nav
      id="main-nav"
      className={cn(
        "fixed top-0 w-full z-50 px-6 py-6 flex justify-between items-center pointer-events-none transition-colors duration-300",
        isPreloading ? "text-primary" : "mix-blend-difference text-white",
        { "text-white !mix-blend-normal": menuOpen }
      )}
    >
      <Link href="/" className="pointer-events-auto magnetic mix-blend-normal">
        {logo ? (
          <Image 
            src={logo.imageUrl}
            alt="Ylamante Elec Logo"
            width={48}
            height={48}
            className="w-10 h-10 md:w-12 md:h-12"
            priority
          />
        ) : (
          <span className="font-display text-xl tracking-widest">YL.</span>
        )}
      </Link>
      
      <button 
        id="menu-toggle"
        onClick={toggleMenu}
        aria-label="Toggle Menu"
        className="w-10 h-10 md:w-12 md:h-12 flex flex-col justify-center items-center gap-1.5 md:gap-2 pointer-events-auto magnetic group z-50"
      >
        <span 
          className={cn(
            "w-2.5 h-2.5 bg-current rounded-full transition-all duration-500 ease-in-out",
            { "transform translate-y-[11px] md:translate-y-[13px] rotate-45 scale-x-[3.5] h-0.5 rounded-none": menuOpen }
          )}
        ></span>
        <span 
          className={cn(
            "w-2.5 h-2.5 bg-current rounded-full transition-opacity duration-300",
            { "opacity-0": menuOpen }
          )}
        ></span>
        <span 
          className={cn(
            "w-2.5 h-2.5 bg-current rounded-full transition-all duration-500 ease-in-out",
            { "transform -translate-y-[11px] md:-translate-y-[13px] -rotate-45 scale-x-[3.5] h-0.5 rounded-none": menuOpen }
          )}
        ></span>
      </button>
    </nav>
  );
}
