"use client"

import { useState, useEffect, useCallback, useLayoutEffect } from 'react';
import { usePathname } from 'next/navigation';
import { Header } from './header';
import { MenuOverlay } from './menu-overlay';
import { Footer } from './footer';
import { Preloader } from './preloader';
import { CustomCursor } from './custom-cursor';

declare global {
  interface Window {
    gsap: any;
    ScrollTrigger: any;
  }
}

export function InteractiveProvider({ children }: { children: React.ReactNode }) {
  const [isPreloading, setIsPreloading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();

  const toggleMenu = useCallback(() => {
    setMenuOpen(prev => !prev);
  }, []);

  const closeMenu = useCallback(() => {
    setMenuOpen(false);
  }, []);
  
  useEffect(() => {
    // Close menu on route change
    closeMenu();
  }, [pathname, closeMenu]);

  useEffect(() => {
    // Prevent body scroll when menu is open
    if (menuOpen) {
      document.body.classList.add('overflow-hidden');
    } else {
      document.body.classList.remove('overflow-hidden');
    }
    return () => {
      document.body.classList.remove('overflow-hidden');
    };
  }, [menuOpen]);

  useLayoutEffect(() => {
    if (isPreloading || typeof window.gsap === 'undefined' || typeof window.ScrollTrigger === 'undefined') return;

    // Kill old triggers to prevent memory leaks on page change
    ScrollTrigger.getAll().forEach(trigger => trigger.kill());

    // Refresh ScrollTrigger for new page content
    ScrollTrigger.refresh();

    // Reveal animations for elements with gs-reveal class
    const reveals = document.querySelectorAll('.gs-reveal, .gs-reveal-page');
    reveals.forEach(elem => {
      gsap.fromTo(elem, 
        { y: 50, opacity: 0 }, 
        {
          y: 0, opacity: 1, duration: 1, ease: "power3.out",
          scrollTrigger: {
            trigger: elem,
            start: "top 85%",
            toggleActions: "play none none restart",
          }
        }
      );
    });

    // Page entrance animations
    // Use a key on the child div to trigger this on route change
    const pageContainer = document.querySelector('[data-page-container]');
    if (pageContainer) {
        gsap.fromTo(pageContainer.children,
            { y: 40, opacity: 0 },
            { y: 0, opacity: 1, duration: 1, stagger: 0.1, ease: "power3.out", delay: 0.2 }
        );
    }
    
    if (pathname === '/') {
        gsap.fromTo(".hero-elem", 
            { y: 40, opacity: 0 }, 
            { y: 0, opacity: 1, duration: 1, stagger: 0.1, ease: "power3.out", delay: 0.2 }
        );
    } else {
        gsap.fromTo(".gs-reveal-page",
            { y: 40, opacity: 0 },
            { y: 0, opacity: 1, duration: 1, stagger: 0.1, ease: "power3.out", delay: 0.2 }
        );
    }

  }, [pathname, isPreloading]);

  return (
    <>
      <div className="noise-overlay"></div>
      <CustomCursor />
      {isPreloading && <Preloader onFinished={() => setIsPreloading(false)} />}
      
      <Header menuOpen={menuOpen} toggleMenu={toggleMenu} isPreloading={isPreloading} />
      <MenuOverlay menuOpen={menuOpen} closeMenu={closeMenu} />
      
      <div key={pathname} data-page-container>
        {children}
      </div>

      <Footer />
    </>
  );
}
