"use client";

import Link from "next/link";
import { useState, useEffect } from "react";

export function Footer() {
    const [year, setYear] = useState<number | null>(null);

    useEffect(() => {
        setYear(new Date().getFullYear());
    }, []);

    return (
        <footer className="bg-primary text-primary-foreground py-16 md:py-24 px-6 text-center relative overflow-hidden" id="global-footer">
            <div className="max-w-5xl mx-auto relative z-10">
                <h2 className="font-display text-4xl md:text-6xl mb-8">Prêt à illuminer votre projet ?</h2>
                <Link href="/#booking" scroll={true} className="inline-block bg-accent text-primary px-8 py-4 text-sm tracking-widest uppercase magnetic mb-16 hover:bg-white transition-colors duration-300">
                    Contactez-nous
                </Link>
                
                <div className="flex flex-col md:flex-row justify-between items-center text-xs tracking-widest uppercase text-white/30 border-t border-white/10 pt-8">
                    <p>&copy; {year || new Date().getFullYear()} Ylamante Elec. Artisan Multiservices.</p>
                    <div className="flex gap-6 mt-4 md:mt-0">
                        <a href="mailto:ylamante-elec10@gmail.com" className="hover:text-accent transition-colors magnetic">Email</a>
                        <a href="tel:0660399642" className="hover:text-accent transition-colors magnetic">06 60 39 96 42</a>
                    </div>
                </div>
            </div>
        </footer>
    )
}
