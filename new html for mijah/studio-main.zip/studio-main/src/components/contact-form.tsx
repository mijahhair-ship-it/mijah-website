"use client";

import { useState, useRef, FormEvent } from "react";
import { useToast } from "@/hooks/use-toast";

export function ContactForm() {
  const [status, setStatus] = useState<string>("");
  const [isPending, setIsPending] = useState<boolean>(false);
  const formRef = useRef<HTMLFormElement>(null);
  const { toast } = useToast();

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsPending(true);
    setStatus("Envoi en cours...");

    const formData = new FormData(event.currentTarget);
    const data = {
      name: formData.get("name"),
      email: formData.get("email"),
      message: formData.get("message"),
    };

    // Form validation
    if (!data.name || !data.email || !data.message) {
      toast({
        title: "Erreur de validation",
        description: "Veuillez remplir tous les champs.",
        variant: "destructive",
      });
      setIsPending(false);
      setStatus("");
      return;
    }

    // TODO: Replace with Firebase submission logic
    console.log("Form Data:", data);

    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    toast({
      title: "Succès!",
      description: "Demande bien reçue. Nous vous contacterons très prochainement.",
    });

    setIsPending(false);
    setStatus("Demande bien reçue.");
    formRef.current?.reset();
    
    setTimeout(() => setStatus(""), 5000);
  };

  return (
    <form ref={formRef} onSubmit={handleSubmit} className="space-y-8">
      <div className="input-group">
        <input type="text" id="name" name="name" placeholder=" " required className="magnetic-input" />
        <label htmlFor="name">Nom complet</label>
      </div>
      <div className="input-group">
        <input type="email" id="email" name="email" placeholder=" " required className="magnetic-input" />
        <label htmlFor="email">Adresse e-mail</label>
      </div>
      <div className="input-group">
        <textarea id="message" name="message" rows={4} placeholder=" " required className="resize-none magnetic-input"></textarea>
        <label htmlFor="message">Détails de votre projet</label>
      </div>
      <button type="submit" disabled={isPending} className="magnetic group relative overflow-hidden bg-primary text-primary-foreground px-8 py-4 w-full text-sm tracking-widest uppercase mt-8">
        <span className="relative z-10 transition-colors group-hover:text-primary">
          {isPending ? "Envoi en cours..." : "Envoyer la demande"}
        </span>
        <div className="absolute inset-0 bg-accent translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out z-0"></div>
      </button>
    </form>
  );
}
