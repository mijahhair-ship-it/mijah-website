"use client"

import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";

export function HeroBlobs() {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const pathname = usePathname();
    const animationFrameId = useRef<number>();

    useEffect(() => {
        if (pathname !== '/') return;

        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const resizeCanvas = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);
        
        let time = 0;

        const animate = () => {
            if(!ctx || !canvas) return;
            
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            time += 0.005;
            
            ctx.filter = 'blur(40px)';

            ctx.beginPath();
            let cx = canvas.width / 2;
            let cy = canvas.height / 2;
            let r = Math.min(cx, cy) * 0.7;
            for (let i = 0; i <= Math.PI * 2; i += 0.1) {
                let x = cx + Math.cos(i) * r + Math.sin(i * 3 + time) * 30;
                let y = cy + Math.sin(i) * r + Math.cos(i * 2 + time) * 30;
                if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.closePath();
            
            let gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
            gradient.addColorStop(0, 'rgba(212, 175, 55, 0.02)');
            gradient.addColorStop(1, 'rgba(212, 175, 55, 0.05)');

            ctx.fillStyle = gradient;
            ctx.fill();

            animationFrameId.current = requestAnimationFrame(animate);
        };
        
        // Start animation only on home page
        if (pathname === '/') {
            animate();
        }

        return () => {
            window.removeEventListener('resize', resizeCanvas);
            if (animationFrameId.current) {
                cancelAnimationFrame(animationFrameId.current);
            }
        };

    }, [pathname]);

    if (pathname !== '/') return null;

    return (
        <canvas id="blobs-canvas" ref={canvasRef} className="absolute inset-0 z-0 pointer-events-none opacity-60"></canvas>
    );
}
