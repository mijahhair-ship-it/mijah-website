"use client"

import { useEffect, useRef } from "react";

declare global {
  interface Window {
    gsap: any;
  }
}

type PreloaderProps = {
    onFinished: () => void;
};

export function Preloader({ onFinished }: PreloaderProps) {
    const preloaderRef = useRef<HTMLDivElement>(null);
    const textRef = useRef<HTMLHeadingElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
      if (typeof window.gsap === 'undefined') {
        onFinished();
        return;
      }

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      let dustParticles: any[] = [];
      const isTouch = window.matchMedia("(pointer: coarse)").matches;
      
      const resizeCanvas = () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      };
      resizeCanvas();
      window.addEventListener('resize', resizeCanvas);
      
      class DustParticle {
          x: number;
          y: number;
          radius: number;
          vy: number;
          alpha: number;

          constructor() {
              this.x = Math.random() * canvas.width; this.y = Math.random() * canvas.height;
              this.radius = Math.random() * 1.5; this.vy = Math.random() * 0.5 + 0.1; this.alpha = Math.random();
          }
          update() { this.y += this.vy; if (this.y > canvas.height) { this.y = 0; this.x = Math.random() * canvas.width; } }
          draw() { 
              if(!ctx) return;
              ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fillStyle = `rgba(212, 175, 55, ${this.alpha})`; ctx.fill(); 
          }
      }
      for(let i=0; i<(isTouch?30:100); i++) dustParticles.push(new DustParticle());
      
      let animationFrameId: number;
      function animateDust() { 
          if(!ctx || !canvas) return;
          ctx.clearRect(0, 0, canvas.width, canvas.height); 
          dustParticles.forEach(p => { p.update(); p.draw(); }); 
          animationFrameId = requestAnimationFrame(animateDust); 
      }
      animateDust();

      const tl = window.gsap.timeline({
          onComplete: () => {
            onFinished();
            if (animationFrameId) cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resizeCanvas);
          }
      });
      
      tl.to(textRef.current, { opacity: 1, duration: 1.5, ease: "power2.inOut" })
        .to(textRef.current, { opacity: 0, duration: 1, delay: 0.5, ease: "power2.inOut" })
        .to(preloaderRef.current, { yPercent: -100, duration: 1.2, ease: "expo.inOut" });
      
      return () => {
          if (animationFrameId) cancelAnimationFrame(animationFrameId);
          window.removeEventListener('resize', resizeCanvas);
      }
    }, [onFinished]);

    return (
        <div ref={preloaderRef} className="fixed inset-0 bg-background z-[9000] flex items-center justify-center">
            <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none"></canvas>
            <h1 ref={textRef} className="font-display text-4xl md:text-6xl tracking-widest text-primary opacity-0">
                YLAMANTE<span className="text-accent">.</span>
            </h1>
        </div>
    );
}
