import { cn } from "@/lib/utils";
import Link from "next/link";

const navLinks = [
    { href: '/', label: 'Accueil' },
    { href: '/about', label: 'L\'Artisan' },
    { href: '/portfolio', label: 'Réalisations' },
    { href: '/#booking', label: 'Contact', scroll: true },
];

type MenuOverlayProps = {
    menuOpen: boolean;
    closeMenu: () => void;
}

export function MenuOverlay({ menuOpen, closeMenu }: MenuOverlayProps) {
    return (
        <div id="menu-overlay" className={cn({ open: menuOpen })}>
            {navLinks.map((link) => (
                <Link 
                    key={link.href}
                    href={link.href}
                    scroll={link.scroll}
                    onClick={closeMenu}
                    className="menu-link magnetic"
                >
                    {link.label}
                </Link>
            ))}

            <div className="absolute bottom-10 left-0 w-full text-center text-sm tracking-widest uppercase text-white/40">
                <a href="mailto:ylamante-elec10@gmail.com" className="hover:text-accent transition-colors magnetic">ylamante-elec10@gmail.com</a>
            </div>
        </div>
    );
}
