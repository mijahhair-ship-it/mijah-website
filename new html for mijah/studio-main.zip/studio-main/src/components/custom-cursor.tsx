"use client"

import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";

declare global {
  interface Window {
    gsap: any;
  }
}

export function CustomCursor() {
    const cursorDotRef = useRef<HTMLDivElement>(null);
    const cursorCircleRef = useRef<HTMLDivElement>(null);
    const cursorTextRef = useRef<HTMLSpanElement>(null);
    const pathname = usePathname();

    useEffect(() => {
        if (typeof window.gsap === 'undefined') return;

        // Check for touch device and hide cursor elements if so
        if (window.matchMedia("(pointer: coarse)").matches) {
            if(cursorDotRef.current) cursorDotRef.current.style.display = 'none';
            if(cursorCircleRef.current) cursorCircleRef.current.style.display = 'none';
            return;
        }

        const cursorDot = cursorDotRef.current;
        const cursorCircle = cursorCircleRef.current;
        
        if (!cursorDot || !cursorCircle) return;

        let mouseX = 0, mouseY = 0, circleX = 0, circleY = 0;

        const handleMouseMove = (e: MouseEvent) => {
            mouseX = e.clientX; 
            mouseY = e.clientY;
            window.gsap.set(cursorDot, { x: mouseX, y: mouseY });
        };
        document.addEventListener('mousemove', handleMouseMove);

        const ticker = () => {
            const dt = 1.0 - Math.pow(1.0 - 0.15, window.gsap.ticker.deltaRatio());
            circleX += (mouseX - circleX) * dt; 
            circleY += (mouseY - circleY) * dt;
            window.gsap.set(cursorCircle, { x: circleX, y: circleY });
        };
        window.gsap.ticker.add(ticker);

        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            window.gsap.ticker.remove(ticker);
        };
    }, []);

    useEffect(() => {
        if (typeof window.gsap === 'undefined' || window.matchMedia("(pointer: coarse)").matches) return;
        
        const cursorText = cursorTextRef.current;
        if (!cursorText) return;

        const bindMagnetics = () => {
            const magnetics = document.querySelectorAll('.magnetic');
            const mediaItems = document.querySelectorAll('.interactive-media');

            magnetics.forEach((elem: any) => {
                elem.addEventListener('mouseenter', () => document.body.classList.add('cursor-hover'));
                elem.addEventListener('mouseleave', () => {
                    document.body.classList.remove('cursor-hover');
                    window.gsap.to(elem, { x: 0, y: 0, duration: 0.5, ease: "elastic.out(1, 0.3)" });
                });
                elem.addEventListener('mousemove', (e: MouseEvent) => {
                    const rect = elem.getBoundingClientRect();
                    const x = e.clientX - rect.left - rect.width / 2;
                    const y = e.clientY - rect.top - rect.height / 2;
                    window.gsap.to(elem, { x: x * 0.3, y: y * 0.3, duration: 0.5, ease: "power2.out" });
                });
            });

            mediaItems.forEach(elem => {
                elem.addEventListener('mouseenter', () => {
                    document.body.classList.add('cursor-media');
                    if(elem.classList.contains('cursor-video')) cursorText.textContent = "Jouer";
                    else cursorText.textContent = "Voir";
                });
                elem.addEventListener('mouseleave', () => {
                    document.body.classList.remove('cursor-media');
                });
            });
        };
        
        // Delay binding to ensure all elements are in the DOM after page transitions
        const timer = setTimeout(bindMagnetics, 500);

        return () => clearTimeout(timer);
    }, [pathname]);

    return (
        <>
            <div ref={cursorDotRef} className="cursor-dot"></div>
            <div ref={cursorCircleRef} className="cursor-circle">
                <span ref={cursorTextRef} className="cursor-text">Voir</span>
            </div>
        </>
    );
}
