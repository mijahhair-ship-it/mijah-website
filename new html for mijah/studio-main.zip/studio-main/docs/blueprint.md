# **App Name**: Ylamante Elec

## Core Features:

- Consultation Request Form: A responsive form allowing potential clients to request consultation or quotes, powered by Netlify for submission handling.
- Dynamic Project Portfolio: Showcase past projects with an interactive grid of images and video placeholders, featuring hover effects and detail overlays.
- Client Testimonial Carousel: Display customer feedback and reviews in an engaging, horizontally scrolling section with a snap-to-item effect.
- Custom Interactive Cursor: An animated custom cursor with magnetic interaction effects on various UI elements, enhancing user engagement.
- Animated Visual Effects: Subtle visual effects including a film grain overlay, dynamic background blobs on the homepage, and GSAP-powered scroll-triggered animations for elements.
- AI Project Description Tool: A backend tool (for the artisan) that uses generative AI to craft professional and detailed project descriptions for new client jobs based on brief inputs about the scope and outcome.
- Service Overview Pages: Dedicated pages outlining the artisan's multiservice offerings including electrical work, lighting design, and home rehabilitation, designed for clear readability.

## Style Guidelines:

- Primary Color: A warm, deep stone brown (#4F3B2C), representing craftsmanship and reliability, suitable for main headings and interactive elements.
- Background Color: A very light, inviting cream-white (#FAFAF9), providing a clean and serene canvas as per user specification.
- Accent Color: A vibrant, distinguished gold (#D4AF37), used for highlights, calls-to-action, and key brand elements as per user specification.
- Headings ('display'): 'Space Grotesk' (sans-serif), lending a modern, distinct, and tech-influenced feel.
- Body Text ('sans'): 'Inter' (sans-serif), for clean readability and a contemporary, objective aesthetic.
- Utilize clean, minimalist line-based SVG icons that complement the modern aesthetic and effectively convey service categories (e.g., lightning bolt for electrical, house outline for rehabilitation).
- Implement spacious, responsive grid-based layouts with clear content separation, centered text alignment for key messages, and liberal use of white space to emphasize serenity and clarity.
- Integrate subtle yet elegant animations powered by GSAP, including scroll-triggered fade-ins and slides for sections, fluid magnetic interactions for clickable elements, and smooth transitions for page navigation, enhancing overall user experience.